/**
 * Minimal glob matching for the exclude list (plan item 7). Supports `*`
 * (within one path segment), `**` (across segments), and `?` (one char).
 * Patterns are matched against the forward-slash-normalized absolute path.
 */
/** Convert one glob pattern to an anchored RegExp (forward-slash paths). */
export declare function globToRegExp(glob: string): RegExp;
/**
 * True when `absPath` matches any glob in the list. Path separators are
 * normalized to forward slashes so a node_modules pattern works on Windows too.
 */
export declare function matchesAnyGlob(absPath: string, globs: readonly string[]): boolean;
//# sourceMappingURL=glob.d.ts.map
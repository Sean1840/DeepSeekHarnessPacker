import type { LedgerSegment } from './types.ts';
/**
 * Diff two fingerprint arrays. Returns an array of length oldFps.length where
 * index i (old line i+1) holds the matched NEW line number (1-based), or undefined
 * when no new line matches. Prefix and suffix lines match positionally; the middle
 * is matched by LCS. When the middle is too large for one DP table, unique
 * fingerprints (once in each side) split it into smaller LCS slices; a slice
 * still over the cell cap with no unique anchors is left unmatched.
 */
export declare function diffLines(oldFps: string[], newFps: string[]): (number | undefined)[];
/**
 * Remap mounted segments (old coordinates) through a diff into new coordinates.
 * Surviving lines keep their ranges (contiguous survivors stay contiguous);
 * changed or deleted lines drop out. Adjacent surviving runs merge and carry
 * their freshness metadata through (earliest born, max expired) and a
 * line-count-proportional token estimate.
 */
export declare function remapSegments(segments: readonly LedgerSegment[], oldToNew: readonly (number | undefined)[]): LedgerSegment[];
/** Counts of added/removed/unchanged lines a diff implies (for the remount note). */
export declare function diffStats(oldToNew: readonly (number | undefined)[], newLineCount: number): {
    added: number;
    removed: number;
    unchanged: number;
};
//# sourceMappingURL=diff.d.ts.map
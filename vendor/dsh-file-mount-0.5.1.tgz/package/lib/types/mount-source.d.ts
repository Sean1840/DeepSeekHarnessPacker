/**
 * The ONE ledger rule shared by the host half (MountStore.replay) and the
 * browser half (foldMounts): source validation + the same-hash-unions /
 * hash-change-replaces merge. Editing the fold semantics here edits both
 * halves at once (plan item 20).
 *
 * Freshness (pressure × depth): each segment carries `born` (context
 * position in input tokens at mount time) and `expired` (how many times the
 * content expired and was re-read). Pressure stays 0 until L exceeds
 * 0.95 W, so mounts last most of the session. After pinAfter expiries
 * (default 1) the segment stays on the ledger.
 */
import type { ExpiredSegment, LedgerSegment, MountKind } from './types.ts';
/** Saturating addition: the token counters never overflow the safe-int range. */
export declare function saturatingAdd(a: number, b: number): number;
/**
 * Normalize ledger segments: sort ascending, merge overlapping ranges (newer
 * mount's born wins). Adjacent ranges merge ONLY when their born values are
 * identical (or both unknown) so a newly refreshed born is not swallowed by
 * an older neighbor.
 */
export declare function normalizeLedger(segments: readonly LedgerSegment[]): LedgerSegment[];
/** What one mount message adds to the ledger (post-validation). */
export interface MountDelta {
    hash: string;
    totalLines: number;
    segments: LedgerSegment[];
    savedTokens: number;
    spentTokens: number;
}
/** A validated file-mount source: the identity plus the delta it carries. */
export interface ParsedMountSource {
    path: string;
    mountKind: MountKind;
    delta: MountDelta;
}
/**
 * Validate a file-mount source (the injected message's structured source).
 * Returns undefined for foreign or malformed shapes, so a foreign log never
 * breaks the ledger. Segments without freshness fields (pre-freshness
 * messages) fold with born undefined and expired 0.
 */
export declare function parseMountSource(source: unknown): ParsedMountSource | undefined;
/** Fold state shared by the host ledger and the browser view. */
export interface MountState {
    hash: string;
    totalLines: number;
    segments: LedgerSegment[];
    savedTokens: number;
    spentTokens: number;
}
/**
 * The fold rule: same hash unions segments and accumulates tokens; a hash
 * change replaces the entry wholesale (the old mount is stale) while the
 * cumulative totals survive.
 */
export declare function applyMountState(existing: MountState | undefined, delta: MountDelta): MountState;
/** Result of pruning expired segments off the ledger. */
export interface PruneResult {
    /** Segments that are still fresh (kept on the ledger). */
    active: LedgerSegment[];
    /** The expired ones with their count bumped (moved to per-file history). */
    history: ExpiredSegment[];
}
export interface FreshnessOptions {
    /** Fraction of W below which pressure is 0 (default 0.95). Ignored when `safeTokens` is set. */
    safeRatio?: number;
    /** Absolute Lsafe override for tests / rare config; takes precedence over `safeRatio`. */
    safeTokens?: number;
    /** Expired count at which a segment is pinned (score 1, never pruned). */
    pinAfter?: number;
    /** Context window W in tokens (default 128k). */
    contextWindow?: number;
    /** Optional cap: segments larger than this are not expired this round. */
    resendBudget?: number;
    /** Times this segment has already expired (pin check). */
    expired?: number;
}
export declare const DEFAULT_FRESHNESS_CONFIG: {
    readonly threshold: 0.6;
    readonly safeRatio: 0.95;
    readonly pinAfter: 1;
    readonly contextWindow: 128000;
    readonly valveReads: 2;
};
/**
 * Pressure × depth freshness: mounts stay fresh until the prompt is near
 * the window (Lsafe = 0.95 W by default). Pinned segments (expired >= pinAfter)
 * always score 1.
 *
 * pressure = sqrt(clamp01((L - Lsafe) / (W - Lsafe)))
 * depth    = clamp01((L - (pos + size/2)) / L)
 * score    = expired >= pinAfter ? 1 : 1 - pressure * depth
 */
export declare function calculateFreshnessScore(born: number, contextL: number, tokens?: number, options?: FreshnessOptions): number;
/**
 * Lazy freshness check: a segment is expired when its score dips below
 * threshold. Pinned segments (expired >= pinAfter) and segments over
 * resendBudget stay on the ledger. Segments without a born or with
 * born >= contextL are never pruned.
 */
export declare function pruneExpired(segments: readonly LedgerSegment[], contextL: number | undefined, threshold?: number, options?: FreshnessOptions): PruneResult;
/**
 * Let freshly mounted segments inherit the expired count of overlapping
 * history entries (the content was re-read after expiring), then drop those
 * history entries (the range is fresh again). Overlaps are counted once per
 * history item (max across all overlapping items wins for every new segment).
 */
export declare function inheritHistory(segments: readonly LedgerSegment[], history: readonly ExpiredSegment[]): {
    segments: LedgerSegment[];
    history: ExpiredSegment[];
};
//# sourceMappingURL=mount-source.d.ts.map
/**
 * Per-session mount ledger. One writer: the plugin's post-execute handler,
 * serialized by the tool pipeline. Replay folds the plugin-injected context
 * messages' structured sources so a resumed session (and the browser client)
 * reconstruct the same state from standard, persistence-safe events. The
 * validation and fold rules live in mount-source.ts, shared with the browser
 * half (plan item 20).
 */
import type { ExpiredSegment, LedgerSegment, MountedFile } from './types.ts';
/** One user/message record as the ledger consumer reads it. */
export interface LedgerRecord {
    type: string;
    source: unknown;
}
export declare class MountStore {
    private files;
    get(absPath: string): MountedFile | undefined;
    all(): MountedFile[];
    mountedSegments(absPath: string): LedgerSegment[];
    /**
     * Union a mounted window into the ledger via the shared fold rule. A hash
     * mismatch proves the on-disk content changed, so the previous entry is
     * replaced wholesale; saved/spent totals are session-cumulative and survive
     * a hash-change replacement.
     */
    mount(file: MountedFile): void;
    /**
     * Explicitly replace active segments and update expired history on an
     * existing entry (e.g. after pruneExpired in full-dedup branches).
     * Unlike `mount()`, this does NOT union old segments back.
     * Saved and spent tokens are accumulated if provided.
     */
    replaceSegments(absPath: string, segments: readonly LedgerSegment[], expiredHistory: readonly ExpiredSegment[], savedTokens?: number, spentTokens?: number): void;
    /** Drop one entry (hash change / explicit invalidation). */
    invalidate(absPath: string): void;
    /**
     * Fold user/message records in log order; a file-mount source updates the
     * ledger with its post-mount ranges. Unknown or malformed records are
     * skipped defensively (foreign logs must never break the ledger).
     */
    replay(records: readonly LedgerRecord[]): void;
    clear(): void;
}
//# sourceMappingURL=store.d.ts.map
/**
 * Canonical identity for mounted files: absolute, symlink-resolved (a soft
 * link unifies to its real file), and case-folded on case-insensitive
 * filesystems so `SRC/Foo.TS` and `src/foo.ts` share one ledger entry
 * (plan item 22).
 */
export declare function normalizeAbsPath(absPath: string): string;
/**
 * Model-facing path for marker heads: relative to `cwd` with forward slashes
 * when the file is inside the workspace. Files outside `cwd` (or when `cwd`
 * is missing) stay absolute, also posix-ified. Ledger identity stays on
 * {@link normalizeAbsPath}.
 */
export declare function displayPath(filePath: string, cwd: string | undefined): string;
//# sourceMappingURL=paths.d.ts.map
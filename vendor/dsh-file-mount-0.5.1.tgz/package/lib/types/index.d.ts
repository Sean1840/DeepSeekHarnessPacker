/**
 * dsh-file-mount host half: incremental file mounting with read dedupe.
 *
 * One post-execute interception point owns the whole model-facing surface:
 * after a successful text `read`, the plugin verifies the file identity
 * (stat-verified cache), folds the returned window against the per-session
 * mount ledger, and returns a PostToolDecision that (a) puts missing or
 * changed line bodies into the durable tool-result content (so cancel cannot
 * drop them), (b) replaces a fully-covered window with a short marker, and
 * (c) injects a head-only ledger notice as plugin-sourced additionalContexts.
 * The canonical tool value is preserved throughout, so UI read cards and the
 * audit log stay intact.
 *
 * The ledger's durable carrier is the injected message SOURCE (structured,
 * merge-extensible JSON on a standard `user/message` event), so resumed
 * sessions and the browser client fold state from persistence-safe events.
 *
 * Compaction-aware: mount messages shadowed by a compact checkpoint no longer
 * count as mounted (their content has left the model context) — both when the
 * live log gains a checkpoint and when a resumed session replays the log.
 *
 * @module dsh-file-mount
 */
import type { Context } from '@deepseek-ai/cordis';
import { Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { MountedFile } from './types.ts';
export { FileContentCache } from './file-cache.ts';
export { MountStore, type LedgerRecord } from './store.ts';
export { normalize, subtract, type LineRange } from './ranges.ts';
export { hashBuffer } from './hash.ts';
export { displayPath, normalizeAbsPath } from './paths.ts';
export { formatRange, markerHead, renderDedupMarker, renderMountBlock, renderRemountMarker, } from './render.ts';
export type { MountedFile, MountKind, MountSource, Segment } from './types.ts';
/** Plugin config: ledger limits and the global kill switch. */
export interface Config {
    /** Master switch; disabled keeps every read native. */
    enabled?: boolean;
    /** File identity cache capacity (pinned mounts exempt). */
    capacity?: number;
    /** File identity cache TTL (safety valve, ms). */
    ttlMs?: number;
    /** Per-session mounted-file pin cap (bounds the identity cache). */
    maxPinnedFiles?: number;
    /** Minimum token saving before a dedup is worth the marker overhead. */
    minSavedTokens?: number;
    /** Files larger than this keep no line fingerprints (whole-window remount). */
    maxFingerprintBytes?: number;
    /** Glob patterns of paths the plugin never manages (e.g. node_modules). */
    excludeGlobs?: string[];
    /** Files larger than this are not managed at all (never read or cached). */
    maxManagedBytes?: number;
    /** Optional path of the cross-session stats file (plan item 24). */
    statsFile?: string;
    /** Freshness tracking: deep content expires as the prompt fills the window. */
    freshnessEnabled?: boolean;
    /** Score below which a segment counts as expired (0..1, default 0.6). */
    freshnessThreshold?: number;
    /** Fraction of the context window below which pressure is 0 (default 0.95). */
    safeRatio?: number;
    /** Absolute Lsafe override; when set, takes precedence over safeRatio. */
    safeTokens?: number;
    /** Expired count at which a segment is pinned and no longer pruned (default 1). */
    pinAfter?: number;
    /** Context window W in tokens when the session has not reported one (default 128000). */
    contextWindow?: number;
    /** Optional cap: do not expire a segment whose token estimate exceeds this. */
    resendBudget?: number;
    /** Re-read safety valve count (integer >= 0, default 2: pass-through on 2nd full intercept; 0 = disabled). */
    valveReads?: number;
}
export declare const Config: z<Config>;
export declare const name = "file-mount";
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Live mount service: per-session ledgers plus the shared file cache. */
        fileMount: FileMountService;
    }
}
/**
 * Host service: per-session mount ledgers, the stat-verified file identity
 * cache, and resume replay from injected message sources.
 */
export declare class FileMountService extends Service {
    static inject: string[];
    private readonly enabled;
    private readonly maxPinnedFiles;
    private readonly minSavedTokens;
    private readonly cache;
    private readonly stores;
    private readonly restores;
    /** Log length each agent's ledger has folded up to (live checkpoint sweep). */
    private readonly cursors;
    /** Per-session pin LRU: agent id -> mounted paths, most recent last. */
    private readonly pinOrders;
    /** Emit the incompatible-read warning at most once per process. */
    private compatWarned;
    /** Per-session silent-dedup savings waiting to ride the next real message. */
    private readonly pendingDedup;
    /** Per-session current context length (latest request FULL prompt tokens:
     * uncached input + cacheRead + cacheWrite, from usage — DSH counts are
     * disjoint). */
    private readonly contextL;
    private readonly excludeGlobs;
    private readonly statsFile;
    private readonly freshnessEnabled;
    private readonly freshnessThreshold;
    private readonly safeRatio;
    private readonly safeTokens;
    private readonly pinAfter;
    private readonly contextWindow;
    private readonly resendBudget;
    private readonly valveReads;
    /** Per-session consecutive full-dedup intercept counts for safety valve: agentId -> absPath -> count. */
    private readonly valveCounts;
    constructor(ctx: Context, config?: Config);
    /** Fold one successful read into the ledger and reshape the decision. */
    private onReadResult;
    /** Register the model-facing "return the book" tool (plan item 25). */
    private registerForgetTool;
    /** A write puts the full new content into the model's context, so mount the
     * file as already known: the next read dedupes instead of re-sending (plan
     * item 13). The cache identity is invalidated first so no stale draft
     * survives the write. */
    private onWriteResult;
    /** An edit changes only a region, so the whole file is NOT known: mark
     * the cache stale but keep the line-fingerprint draft so the next read
     * re-reads disk and remounts only the changed lines (plan item 9). */
    private onEditResult;
    private getValveCount;
    private setValveCount;
    private clearValveCount;
    /** Take (and clear) the silent-dedup savings pending for a session+file, so
     * they ride the next real message and resume reconstruction stays exact. */
    private takePendingSaved;
    /** Serializes stats-file merges so concurrent disposals cannot lose totals. */
    private statsWrite;
    /** Cross-session ledger (plan item 24): merge one store's totals into the
     * configured stats file (atomic tmp + rename; never throws). */
    private persistStats;
    /** Persist every live store at service shutdown (reliable cross-session
     * totals even though agent/disposed may not precede plugin disposal). */
    private persistAllStats;
    /** Cross-session totals from the stats file (or null when unavailable). */
    stats(): Promise<{
        sessions: number;
        savedTokens: number;
        spentTokens: number;
    } | null>;
    /** Decision body after the cheap guards, isolated so it can never throw out. */
    private onReadResultInner;
    /**
     * Fold extra plugin contexts (and optional content) onto a downstream accept
     * without dropping another listener's additionalContexts. Content is only
     * set when the caller already ruled out a value replacement.
     */
    private acceptWith;
    /** The structured source state for one injected message. */
    private mountSource;
    /** One-line account of a mount (collapsed context-row summary). */
    private mountSummary;
    /** The plugin-sourced context message carrying one mount block. */
    private contextMessage;
    /** Record segments and pin the identity in the file cache for one session. */
    private mount;
    /** Scale a segment's token estimate onto a sub-range by line count.
     * Out-of-window fragments have no lines to re-estimate; writing 0 would
     * look like "unknown volume" and must be avoided. */
    private scaleSegmentTokens;
    /** Stamp fresh-born and tokens on a newly mounted single range (initial read or safety-valve remount). */
    private stampBornNew;
    /** Stamp fresh-born and tokens on newly mounted ranges in an injected block. */
    private stampBornRanges;
    /** Stamp fresh-born on a write mount (tokens unknown, born at status message). */
    private stampBornWrite;
    /** Pin a mounted file for one session, honoring the per-session cap (LRU). */
    private pinFor;
    /** Reconcile the cache pins with one session's current ledger. */
    private resyncPins;
    /** Drop one session's in-memory ledger and cache pins (session teardown). */
    private disposeLedger;
    /** One-time warning when the read result shape is no longer recognized. */
    private warnIncompat;
    /** Per-session ledger, restored lazily on first access (resume race guard). */
    private storeFor;
    /**
     * Mount records whose claims still hold: file-mount messages that no compact
     * checkpoint shadows. Shadowed messages stay in the raw log, but their
     * content has left the model context, so folding them would resurrect
     * stale claims (and enable false dedup).
     */
    private visibleMountRecords;
    /**
     * Fold the live log tail for new compact checkpoints (DSH does not emit a
     * session-start 'compact' notification yet). Any new checkpoint — or a
     * replaced/shrunk log — re-derives the ledger from the still-visible mount
     * messages, so a claim never outlives the content it cites.
     */
    private sweep;
    /** Session-advertised context window, or the configured default. */
    private windowW;
    /** Workspace cwd: session header first, then the local fs plugin config. */
    private workspaceCwd;
    /** Marker-head path relative to the workspace; ledger identity stays absolute. */
    private markerPath;
    /** Tokens reported on one assistant/message (DISJOINT usage sum). */
    private usageTokens;
    /** Rough token count of one visible event's own payload (not the full prompt). */
    private estimateEventTokens;
    private eventText;
    /**
     * Bind carrier seq onto added ranges and refresh `born` from the prefix
     * sum of visible events before that seq. Legacy segments with only `born`
     * keep it as pos.
     */
    private reposition;
    /**
     * Update the per-session context length from one assistant/message usage.
     * DSH's TokenUsage counts are DISJOINT: `inputTokens` is the UNCACHED input
     * only, with the cached prefix reported separately as cacheReadTokens /
     * cacheWriteTokens. Freshness measures a segment's position in the REAL
     * prompt, so the clock must be the sum of all three — using the uncached
     * delta alone makes L wiggle with cache noise (hundreds on hits, the full
     * context on misses), expiring fresh mounts on noise and never expiring
     * buried ones.
     */
    private trackContextLength;
    /** Re-derive the ledger from the still-visible mount messages. */
    private refold;
    /** Replay the ledger from plugin-injected message sources in the live log. */
    private kickoffRestore;
    /** Forget the ledger (clear/compact): the context guarantee is gone. */
    private resetLedger;
    /** Live ledger snapshot for UIs and tests. */
    ledger(agent: Agent): MountedFile[];
}
/**
 * Register the file-mount service (the interception listener lives on the
 * service fiber so its lifecycle rides the plugin's disposal).
 * @param ctx - host context.
 * @param config - plugin config after Loader validation.
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map
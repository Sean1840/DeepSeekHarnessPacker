/**
 * Client-side fold of the mount ledger: one entry per mounted file, upserted
 * from the plugin-injected context messages in conversation-node order. The
 * host's structured message source is the durable carrier, so this fold works
 * live and on resumed history alike. Validation and the merge rule come from
 * mount-source.ts — the SAME rule the host replays with (plan item 20).
 *
 * The browser conversation is a PAGINATED history window (tail page first,
 * older pages only on scroll), so `snapshot.nodes` shrinks at the head as the
 * session grows. {@link MountFold} therefore persists its per-session state
 * across snapshot revisions: a mount message that scrolls out of the loaded
 * window keeps its file on the dashboard, and re-delivered messages are
 * folded exactly once (no double token counts). `foldMounts` remains as the
 * stateless one-shot fold for tests and one-off consumers.
 *
 * Freshness (attention-decay plan): assistant nodes expose per-request usage,
 * so the fold also derives the current context length — the FULL prompt
 * (uncached input + cacheRead + cacheWrite; DSH counts are disjoint) — and
 * each segment's `born` position then maps to a display level (fresh/ok/warn/
 * expired/unknown) via pressure × depth against the host-stamped threshold.
 */
import type { ConversationNode } from '@deepseek-ai/dsh-client-runtime/client';
import type { LedgerSegment } from '../types.ts';
import { type FreshnessOptions } from '../mount-source.ts';
/** One mounted file as the view presents it. */
export interface MountedFileView {
    /** Normalized absolute path (ledger identity). */
    path: string;
    /** Short (8-char) content hash for the identity column. */
    hash: string;
    /** Line count of the file at hash time. */
    totalLines: number;
    /** Mounted ranges, normalized ascending, with freshness metadata. */
    ranges: LedgerSegment[];
    /** How the ledger changed last. */
    mountKind: 'new' | 'increment' | 'remount' | 'dedup';
    /** Cumulative tokens kept out of the context for this path. */
    savedTokens: number;
    /** Cumulative tokens the plugin's own notes cost for this path. */
    spentTokens: number;
    /** Source message seq (stable ordering). */
    seq: number;
    /** Current context length (latest request input tokens), for freshness. */
    contextL?: number;
    /** Freshness expiry threshold the host configured (default 0.6). */
    freshnessThreshold: number;
}
/** Display levels for one segment's freshness. */
export type FreshnessLevel = 'fresh' | 'ok' | 'warn' | 'expired' | 'unknown';
/**
 * Freshness level from pressure × depth: short prompts stay fresh; deep
 * content only decays near the window cap. Pinned segments score as fresh.
 */
export declare function freshnessLevel(born: number | undefined, contextL: number | undefined, threshold?: number, tokens?: number, options?: FreshnessOptions): FreshnessLevel;
/**
 * File-level freshness: expired beats warn beats ok; unknown is its own
 * gray state and must not collapse to green fresh.
 */
export declare function worstFreshness(levels: readonly FreshnessLevel[]): FreshnessLevel;
/**
 * Stateful fold that survives the client's paginated history window. Per
 * session it keeps every validated mount message per path and re-derives the
 * entry in seq order on each fold, so (a) messages that scroll out of the
 * loaded window keep their file visible, (b) re-delivered messages fold
 * exactly once, and (c) older messages arriving later (page-up) cannot
 * overwrite newer state. A sessionId change resets the accumulated state.
 */
export declare class MountFold {
    private sessionId;
    private readonly paths;
    private readonly folded;
    private lastThreshold;
    private lastThresholdSeq;
    /**
     * Fold one snapshot revision (ascending seq) into the persistent state.
     * @param sessionId - owning conversation; a change resets the fold.
     * @param nodes - the currently loaded conversation nodes (windowed).
     * @returns the mounted-file views (sorted by last message seq).
     */
    fold(sessionId: string, nodes: readonly ConversationNode[]): MountedFileView[];
}
/**
 * One-shot fold of a node list (stateless). The live dashboard should use
 * {@link MountFold}, which persists across the paginated history window.
 * Foreign or malformed nodes are skipped; a hash change replaces the entry
 * wholesale (the old mount is stale), same-hash messages union their ranges.
 */
export declare function foldMounts(nodes: readonly ConversationNode[]): MountedFileView[];
//# sourceMappingURL=mounted-files.d.ts.map
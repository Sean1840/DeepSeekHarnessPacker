/** `file-mount` namespace dictionaries (view tab label + list strings). */
/** Dictionary namespace owned by this plugin. */
export declare const NS = "file-mount";
/** The file-mount dictionary key set (the source of truth for both locales). */
export type FileMountKey = 'view.fileMount' | 'list.empty' | 'list.hash' | 'list.lines' | 'list.searchPlaceholder' | 'list.sortNet' | 'list.sortPath' | 'kind.new' | 'kind.increment' | 'kind.remount' | 'kind.dedup' | 'summary.netTotal' | 'summary.cny' | 'summary.breakdown' | 'row.net' | 'row.changed' | 'row.coverage' | 'row.coverageTitle' | 'freshness.fresh' | 'freshness.ok' | 'freshness.warn' | 'freshness.expired' | 'freshness.unknown' | 'freshness.expiredBadge' | 'freshness.expiredTitle' | 'help.title' | 'help.modelTitle' | 'help.modelDesc' | 'help.savingsTitle' | 'help.savingsDesc' | 'help.close';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The mounted-files view tab label and list strings. */
        'file-mount': FileMountKey;
    }
}
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: Record<FileMountKey, string>;
/** English dictionary. */
export declare const en: Record<FileMountKey, string>;
//# sourceMappingURL=locales.d.ts.map
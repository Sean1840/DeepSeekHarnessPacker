/** Mounted-files dashboard: coverage map, search, sort, net savings + a rough
 * CNY figure (plan items 16 + 17), matching the DSH tab styling. */
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
export type MountedFilesViewProps = ConvViewProps & PropsLocale<'file-mount'>;
/**
 * Dashboard over the conversation snapshot: fold the injected mount messages
 * through a persistent {@link MountFold} (one per view instance), so mounts
 * whose messages scroll out of the client's paginated history window stay on
 * the dashboard, then render one row per file with a coverage map, search,
 * and sorting. The fold resets when the conversation (sessionId) changes.
 * @param props - slot standard kit (useSession) plus the view locale seat.
 * @returns the mounted-files dashboard, or the localized empty hint.
 */
export declare function MountedFilesView({ useSession, t }: MountedFilesViewProps): import("react").JSX.Element;
//# sourceMappingURL=MountedFilesView.d.ts.map
/**
 * Full-file identity (ported from piwpi's hash.ts). Hash the RAW BYTES, not
 * the UTF-8 string, so CRLF/encoding normalization cannot make two different
 * on-disk contents collide.
 */
export declare function hashBuffer(buf: Buffer): string;
/**
 * Split raw bytes into lines exactly the way the read tool numbers them, then
 * fingerprint each line. The split mirrors dsh-tool-fs's window scanner:
 * UTF-8 decode, split on a newline, strip a trailing carriage return per line
 * (CRLF), and drop the empty segment a trailing newline leaves behind (so a
 * trailing newline does not add an extra line, and an empty file has zero).
 * Index 0 of the result is line 1.
 *
 * This is the "draft" (底稿) item 9 diffs against: fingerprints only, never
 * the full text, so a draft stays dozens of times smaller than its file.
 */
export declare function fingerprintLines(buf: Buffer): string[];
//# sourceMappingURL=hash.d.ts.map
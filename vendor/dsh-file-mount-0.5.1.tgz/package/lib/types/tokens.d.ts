/**
 * Coarse token estimates for saved-context accounting. CJK characters count
 * as one token each (a Han character is roughly one token); everything else
 * uses the ÷4 rule. A precise tokenizer is deferred.
 */
/**
 * Estimate the token count of a model-facing text: CJK characters count as
 * one token each, the remaining characters as chars ÷ 4 (min 1 overall).
 */
export declare function estimateTokens(text: string): number;
/**
 * Estimate the token count of the given window lines lying inside
 * `ranges` (1-based, in-window). Range bounds outside the window are
 * clamped so foreign ranges never read past the array.
 */
export declare function estimateRangeTokens(lines: readonly string[], windowStart: number, ranges: readonly {
    start: number;
    end: number;
}[]): number;
//# sourceMappingURL=tokens.d.ts.map